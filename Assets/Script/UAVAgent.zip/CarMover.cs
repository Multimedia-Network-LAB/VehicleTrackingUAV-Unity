using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarMover : MonoBehaviour
{
    private Waypoint waypoint;
    private float moveSpeed = 5f;
    private float distanceToWaypoint = 0.1f;
    
    private Transform currentWaypoint;

    private void Awake()
    {
        waypoint = FindObjectOfType<Waypoint>();
        //initializing the current waypoint to the first waypoint
        currentWaypoint = waypoint.GetNextWayPoint(currentWaypoint);
        transform.position = currentWaypoint.position;
        
        //setting the next waypoint
        currentWaypoint = waypoint.GetNextWayPoint(currentWaypoint);
        transform.LookAt(currentWaypoint);
    }

    private void FixedUpdate()
    {
        transform.position = Vector3.MoveTowards(transform.position, currentWaypoint.position, moveSpeed * Time.deltaTime);
        if (Vector3.Distance(transform.position,currentWaypoint.position) < distanceToWaypoint)
        {
            currentWaypoint = waypoint.GetNextWayPoint(currentWaypoint);
            transform.LookAt(currentWaypoint);
        }
    }
    
}